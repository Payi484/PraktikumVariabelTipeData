package com.example.praktikumvariabeltipedata

// Import yang digunakan untuk menjalankan Activity dan komponen Android
import android.os.Bundle
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import java.text.NumberFormat
import java.util.Locale


// Class utama aplikasi
class MainActivity : AppCompatActivity() {

    // Variabel untuk menghubungkan komponen input
    // dari activity_main.xml dengan Kotlin
    private lateinit var etNama: EditText
    private lateinit var etGajiPokok: EditText
    private lateinit var etJamLembur: EditText

    // Variabel untuk tombol dan card hasil
    private lateinit var btnHitung: Button
    private lateinit var cardHasil: CardView

    // Variabel untuk menampilkan hasil perhitungan
    private lateinit var tvNamaHasil: TextView
    private lateinit var tvGajiPokokHasil: TextView
    private lateinit var tvJamLemburHasil: TextView
    private lateinit var tvTotalGaji: TextView
    private lateinit var tvStatus: TextView


    // Fungsi yang pertama kali dijalankan ketika aplikasi dibuka
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Menghubungkan MainActivity dengan tampilan activity_main.xml
        setContentView(R.layout.activity_main)


        // ================= INISIALISASI VIEW =================
        // Menghubungkan setiap komponen pada XML
        // dengan variabel yang sudah dibuat di Kotlin

        etNama = findViewById(R.id.etNama)
        etGajiPokok = findViewById(R.id.etGajiPokok)
        etJamLembur = findViewById(R.id.etJamLembur)

        btnHitung = findViewById(R.id.btnHitung)
        cardHasil = findViewById(R.id.cardHasil)

        // Menghubungkan TextView yang digunakan
        // untuk menampilkan hasil perhitungan
        tvNamaHasil = findViewById(R.id.tvNamaHasil)
        tvGajiPokokHasil = findViewById(R.id.tvGajiPokokHasil)
        tvJamLemburHasil = findViewById(R.id.tvJamLemburHasil)
        tvTotalGaji = findViewById(R.id.tvTotalGaji)
        tvStatus = findViewById(R.id.tvStatus)


        // ================= EVENT TOMBOL =================
        // Menjalankan fungsi hitungGaji() ketika
        // tombol "HITUNG GAJI" ditekan
        btnHitung.setOnClickListener {
            hitungGaji()
        }
    }


    // ================= PROSES PERHITUNGAN =================
    // Fungsi ini digunakan untuk mengambil input,
    // melakukan perhitungan, menentukan status,
    // dan menampilkan hasil
    private fun hitungGaji() {


        // ================= MENGAMBIL INPUT =================
        // Mengambil data yang dimasukkan pengguna
        // dari masing-masing EditText

        val nama = etNama.text.toString().trim()
        val gajiPokokStr = etGajiPokok.text.toString().trim()
        val jamLemburStr = etJamLembur.text.toString().trim()


        // ================= VALIDASI INPUT =================
        // Mengecek apakah semua input sudah diisi.
        // Jika ada yang kosong, program menampilkan pesan
        // dan menghentikan proses perhitungan.

        if (
            nama.isEmpty() ||
            gajiPokokStr.isEmpty() ||
            jamLemburStr.isEmpty()
        ) {
            Toast.makeText(
                this,
                "Mohon lengkapi semua data terlebih dahulu!",
                Toast.LENGTH_SHORT
            ).show()

            return
        }


        // ================= KONVERSI DATA =================
        // Mengubah input gaji menjadi Double
        // dan jam lembur menjadi Integer
        // agar dapat digunakan dalam operasi matematika.

        val gajiPokok = gajiPokokStr.toDoubleOrNull()
        val jamLembur = jamLemburStr.toIntOrNull()


        // Mengecek apakah gaji dan jam lembur
        // benar-benar berupa angka.
        if (gajiPokok == null || jamLembur == null) {

            Toast.makeText(
                this,
                "Gaji Pokok dan Jam Lembur harus berupa angka!",
                Toast.LENGTH_SHORT
            ).show()

            return
        }


        // ================= PERHITUNGAN TOTAL GAJI =================
        // Menghitung total gaji berdasarkan rumus:
        //
        // Total Gaji =
        // Gaji Pokok + (Jam Lembur × Rp20.000)

        val totalGaji = gajiPokok + (jamLembur * 20000)


        // ================= STATUS KESEJAHTERAAN =================
        // Jika total gaji minimal Rp5.000.000,
        // maka statusnya "Sejahtera".
        // Jika kurang dari Rp5.000.000,
        // maka statusnya "Cukup".

        val status = if (totalGaji >= 5_000_000) {
            "Sejahtera"
        } else {
            "Cukup"
        }


        // ================= FORMAT RUPIAH =================
        // Digunakan untuk mengubah angka menjadi
        // format mata uang Rupiah.

        val formatRupiah =
            NumberFormat.getCurrencyInstance(Locale("in", "ID"))


        // ================= MENAMPILKAN HASIL =================
        // Menampilkan data yang sudah diproses
        // ke masing-masing TextView.

        tvNamaHasil.text = "Nama: $nama"

        tvGajiPokokHasil.text =
            "Gaji Pokok: ${formatRupiah.format(gajiPokok)}"

        tvJamLemburHasil.text =
            "Jam Lembur: $jamLembur jam"

        tvTotalGaji.text =
            formatRupiah.format(totalGaji)

        tvStatus.text = status


        // ================= WARNA STATUS =================
        // Mengatur warna badge berdasarkan status.
        // Hijau untuk "Sejahtera" dan warna sesuai
        // resource "cukup" untuk status "Cukup".

        if (status == "Sejahtera") {

            tvStatus.setBackgroundResource(
                R.drawable.bg_status_badge
            )

            tvStatus.background.setTint(
                resources.getColor(
                    R.color.sejahtera,
                    null
                )
            )

        } else {

            tvStatus.setBackgroundResource(
                R.drawable.bg_status_badge
            )

            tvStatus.background.setTint(
                resources.getColor(
                    R.color.cukup,
                    null
                )
            )
        }


        // ================= ANIMASI HASIL =================
        // Menampilkan card hasil dengan animasi
        // fade in agar hasil muncul secara bertahap.

        tampilkanHasilDenganAnimasi()
    }


    // ================= FUNGSI ANIMASI =================
    // Fungsi ini digunakan untuk menampilkan CardView hasil
    // dengan efek muncul secara perlahan.
    private fun tampilkanHasilDenganAnimasi() {

        // Menampilkan CardView hasil
        cardHasil.visibility = View.VISIBLE

        // Membuat tampilan awal menjadi transparan
        cardHasil.alpha = 0f


        // Membuat animasi dari transparan menjadi terlihat
        val fadeIn = AlphaAnimation(0f, 1f)

        // Durasi animasi selama 400 milidetik
        fadeIn.duration = 400

        // Mempertahankan kondisi akhir animasi
        fadeIn.fillAfter = true


        // Menjalankan animasi pada CardView hasil
        cardHasil.startAnimation(fadeIn)

        // Mengubah alpha menjadi 1 secara perlahan
        cardHasil.animate()
            .alpha(1f)
            .setDuration(400)
            .start()
    }
}